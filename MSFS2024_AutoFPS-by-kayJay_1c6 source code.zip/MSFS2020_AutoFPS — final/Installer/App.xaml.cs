﻿using System.Windows;

namespace Installer
{
    public partial class App : Application
    {
    }
}
