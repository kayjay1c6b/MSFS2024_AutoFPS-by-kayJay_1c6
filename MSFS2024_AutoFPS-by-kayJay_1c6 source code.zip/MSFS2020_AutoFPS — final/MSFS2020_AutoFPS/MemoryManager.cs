﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Shapes;

namespace MSFS2020_AutoFPS
{
    public class MemoryManager
    {
        private ServiceModel Model;

        private long addrTLOD;
        private long addrOLOD;
        private long addrTLOD_VR;
        private long addrTLOD_VR2;

        private long addrOLOD_VR;
        private long addrCloudQ;
        private long addrCloudQ_VR;
        private long addrVrMode;
        private long addrFgMode;
        private long offsetPointerAnsioFilter = -0x18;
        private long offsetWaterWaves = 0x3C;
        private bool allowMemoryWrites;
        private bool isDX12 = true;

        public MemoryManager(ServiceModel model)
        {
            try
            {
                this.Model = model;

                MemoryInterface.Attach(Model.SimBinary);

                GetActiveDXVersion();
                Logger.Log(LogLevel.Debug, "MemoryManager:MemoryManager", $"Trying offsetModuleBase: 0x{model.OffsetModuleBase.ToString("X8")}");
                GetMSFSMemoryAddresses();
                if (addrTLOD > 0) MemoryBoundaryTest(true);
                else Logger.Log(LogLevel.Debug, "MemoryManager:MemoryManager", "Failed first TLOD address setting attempt");
                if (!allowMemoryWrites)
                {
                    Logger.Log(LogLevel.Debug, "MemoryManager:MemoryManager", $"Boundary tests failed - possible MSFS memory map change");
                    ModuleOffsetSearch();
                }
                else Logger.Log(LogLevel.Debug, "MemoryManager:MemoryManager", $"Boundary tests passed - memory writes enabled");
                if (!allowMemoryWrites) Logger.Log(LogLevel.Debug, "MemoryManager:MemoryManager", $"Boundary test failed - memory writes disabled");
                GetMSFSMemoryAddresses();

            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:MemoryManager", $"Exception {ex}: {ex.Message}");
            }
        }

        private void ModuleOffsetSearch()
        {
            Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch", "Starting module offset search");

            long moduleBase = MemoryInterface.GetModuleAddress("FlightSimulator2024.exe");
            if (moduleBase == 0)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:ModuleOffsetSearch", "Failed to get module base address");
                return;
            }

            // Define search range (adjust as needed)
            long startOffset = 0x0A000000; // Start 4 MB before the expected offset
            long endOffset = 0x0A800000;   // End 4 MB after the expected offset
            long step = 0x10;              // Keep small step size for precision

            int attempts = 0;
            for (long testOffset = startOffset; testOffset < endOffset; testOffset += step)
            {
                attempts++;
                Model.OffsetModuleBase = testOffset;

                try
                {
                    long pointerBase = moduleBase + testOffset;
                    long pointer = MemoryInterface.ReadMemory<long>(pointerBase);

                    // Calculate key addresses
                    addrTLOD = pointer + Model.OffsetPointerTlod;
                    addrOLOD = pointer + Model.OffsetPointerOlod;
                    addrTLOD_VR = pointer + Model.OffsetPointerTlodVr;
                    addrOLOD_VR = pointer + 0x494; // Using the hardcoded offset you provided

                    // Perform boundary test without logging
                    MemoryBoundaryTest(false);

                    if (allowMemoryWrites)
                    {
                        Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch",
                            $"Found valid module offset: 0x{testOffset:X8} after {attempts} attempts");

                        // Log the found addresses
                        Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch", $"TLOD Address: 0x{addrTLOD:X}");
                        Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch", $"OLOD Address: 0x{addrOLOD:X}");
                        Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch", $"TLOD VR Address: 0x{addrTLOD_VR:X}");
                        Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch", $"OLOD VR Address: 0x{addrOLOD_VR:X}");

                        return; // Exit the method if a valid offset is found
                    }
                }
                catch
                {
                    // Ignore exceptions and continue searching
                }

                // Log progress every 1 MB
                if (attempts % 262144 == 0)
                {
                    Logger.Log(LogLevel.Debug, "MemoryManager:ModuleOffsetSearch",
                        $"Searched {(testOffset - startOffset) / 1024 / 1024} MB... Current offset: 0x{testOffset:X8}");
                }
            }

            Logger.Log(LogLevel.Error, "MemoryManager:ModuleOffsetSearch",
                $"Failed to find a valid module offset after {attempts} attempts");
        }
        private void MemoryBoundaryTest(bool logResult = false)
        {
            // Boundary check a few known setting memory addresses to see if any fail which likely indicates MSFS memory map has changed
            if (GetTLOD_PC() < 10 || GetTLOD_PC() > 1000 || GetTLOD_VR() < 10 || GetTLOD_VR() > 1000
                || GetOLOD_PC() < 10 || GetOLOD_PC() > 1000 || GetOLOD_VR() < 10 || GetOLOD_VR() > 1000
                || GetCloudQ_PC() < 0 || GetCloudQ_PC() > 3 || GetCloudQ_VR() < 0 || GetCloudQ_VR() > 3
                || MemoryInterface.ReadMemory<int>(addrVrMode) < 0 || MemoryInterface.ReadMemory<int>(addrVrMode) > 1)
               
            {
                allowMemoryWrites = false;
            }
            else allowMemoryWrites = true;
            if (logResult && (ServiceModel.TestVersion || !allowMemoryWrites))
            {
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"TLOD PC: {GetTLOD_PC()}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"TLOD VR: {GetTLOD_VR()}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"OLOD PC: {GetOLOD_PC()}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"OLOD VR: {GetOLOD_VR()}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"Cloud Quality PC: {ServiceModel.CloudQualityText(GetCloudQ_PC())}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"Cloud Quality VR: {ServiceModel.CloudQualityText(GetCloudQ_VR())}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"VR Mode: {MemoryInterface.ReadMemory<int>(addrVrMode)}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"Ansio Filter: {MemoryInterface.ReadMemory<int>(addrTLOD + offsetPointerAnsioFilter)}");
                Logger.Log(LogLevel.Debug, "MemoryManager:BoundaryTest", $"Water Waves: {MemoryInterface.ReadMemory<int>(addrTLOD + offsetWaterWaves)}");
            }
        }
        private bool GetMSFSMemoryAddresses()
        {
            try
            {
                 long BaseOffset = Model.OffsetModuleBase;
                long moduleBase = MemoryInterface.GetModuleAddress("FlightSimulator2024.exe");
                if (moduleBase == 0) throw new Exception("Failed to get module base address");

                Logger.Log(LogLevel.Debug, "Address Calculation", $"Module Base Address: 0x{moduleBase:X}");

                long pointerBase = moduleBase + BaseOffset;
                long pointer = MemoryInterface.ReadMemory<long>(pointerBase);

                // Calculate addresses
                addrTLOD = CalculateAddress(pointer, Model.OffsetPointerTlod, "TLOD");
                addrOLOD = CalculateAddress(pointer, Model.OffsetPointerOlod, "OLOD");
                addrTLOD_VR = CalculateAddress(pointer, Model.OffsetPointerTlodVr, "TLOD VR");
                addrOLOD_VR = CalculateAddress(pointer, 0x494, "OLOD VR"); // Using the hardcoded offset you provided

                // Calculate other addresses
                addrVrMode = CalculateAddress(pointer, Model.OffsetPointerVrMode, "TLOD VR");
                addrCloudQ = CalculateAddress(pointer, Model.OffsetPointerCloudQ, "CloudQ");
                addrCloudQ_VR = CalculateAddress(pointer, Model.OffsetPointerCloudQVr, "CloudQ VR");
                addrFgMode = CalculateAddress(pointer, Model.OffsetPointerFgMode, "FG Mode");


            

                // Verify addresses
                VerifyAddresses();

                return true;
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "GetMSFSMemoryAddresses", $"Error: {ex.Message}");
                return false;
            }
        }

        private long CalculateAddress(long baseAddress, long offset, string propertyName)
        {
            long address = baseAddress + offset;
            Logger.Log(LogLevel.Debug, "Address Calculation", $"{propertyName} Address: 0x{address:X}");
            return address;
        }

        private void VerifyAddresses()
        {
            VerifyAddress(addrTLOD, "TLOD");
            VerifyAddress(addrOLOD, "OLOD");
            VerifyAddress(addrTLOD_VR, "TLOD VR");
            VerifyAddress(addrOLOD_VR, "OLOD VR");
            VerifyAddress(addrCloudQ, "CloudQ");
            VerifyAddress(addrCloudQ_VR, "CloudQ VR");
            VerifyAddress(addrVrMode, "VR Mode");
            VerifyAddress(addrFgMode, "FG Mode");
            MemoryBoundaryTest();
        }

        private void VerifyAddress(long address, string propertyName)
        {
            try
            {
                int value = MemoryInterface.ReadMemory<int>(address);
                Logger.Log(LogLevel.Debug, "Address Verification", $"{propertyName} Value: {value}");
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "Address Verification", $"Failed to read {propertyName}: {ex.Message}");
            }
        }
       
        private void GetActiveDXVersion()
        {
            isDX12 = true;

        }

        public bool MemoryWritesAllowed()
        {
                        return allowMemoryWrites;


        }
        public bool IsVrModeActive()
        {
            try
            {
                //return true;
                return MemoryInterface.ReadMemory<int>(addrVrMode) == 1;
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:IsVrModeActive", $"Exception {ex}: {ex.Message}");
            }

            return false;
        }
        [DllImport("user32.dll")]
        static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        public bool IsActiveWindowMSFS()
        {
            const int nChars = 256;
            string activeWindowTitle;
            StringBuilder Buff = new StringBuilder(nChars);
            IntPtr handle = GetForegroundWindow();

            if (GetWindowText(handle, Buff, nChars) > 0)
            {
                activeWindowTitle = Buff.ToString();
                if (activeWindowTitle.Length > 26 && activeWindowTitle.Substring(0, 26) == "Microsoft Flight Simulator 2024")
                    return true;
            }
            return false;
        }
 
        public bool IsDX12()
        {
            return isDX12;
        }
        public bool IsFgModeEnabled()
        {
            try
            {
                if (isDX12 && !Model.MemoryAccess.IsVrModeActive()) 
                    return MemoryInterface.ReadMemory<byte>(addrFgMode) == 1;
                else return false;
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:IsFgModeEnabled", $"Exception {ex}: {ex.Message}");
            }

            return false;
        }

        public float GetTLOD_PC()
        {
            try
            {
                return (float)Math.Round(MemoryInterface.ReadMemory<float>(addrTLOD) * 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:GetTLOD", $"Exception {ex}: {ex.Message}");
            }

            return 0.0f;
        }

        public float GetTLOD_VR()
        {
            try
            {
                return (float)Math.Round(MemoryInterface.ReadMemory<float>(addrTLOD_VR) * 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:GetTLOD_VR", $"Exception {ex}: {ex.Message}");
            }

            return 0.0f;
        }

        public float GetOLOD_PC()
        {
            try
            {
                return (float)Math.Round(MemoryInterface.ReadMemory<float>(addrOLOD) * 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:GetOLOD", $"Exception {ex}: {ex.Message}");
            }

            return 0.0f;
        }

         public float GetOLOD_VR()
        {
            try
            {
                return (float)Math.Round(MemoryInterface.ReadMemory<float>(addrOLOD_VR) * 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:GetOLOD_VR", $"Exception {ex}: {ex.Message}");
            }

            return 0.0f;
        }

        public int GetCloudQ_PC()
        {
            try
            {
                return MemoryInterface.ReadMemory<int>(addrCloudQ);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:GetCloudQ", $"Exception {ex}: {ex.Message}");
            }

            return -1;
        }
        public int GetCloudQ_VR()
        {
            try
            {
                return MemoryInterface.ReadMemory<int>(addrCloudQ_VR);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:GetCloudQ VR", $"Exception {ex}: {ex.Message}");
            }

            return -1;
        }
        public void SetTLOD(float value)
        {
            if (true)
            {   
                SetTLOD_PC(value);
                SetTLOD_VR(value);
            }
        }
        public void SetTLOD_PC(float value)
        {
            try
            {

                Logger.Log(LogLevel.Debug, "MemoryManager:SetTLOD_VR", $"Writing TLOD  for address {addrTLOD}");

                MemoryInterface.WriteMemory<float>(addrTLOD, value / 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:SetTLOD", $"Exception {ex}: {ex.Message}");
            }
        }
        public void SetTLOD_VR(float value)
        {
            try
            {
                Logger.Log(LogLevel.Debug, "MemoryManager:SetTLOD_VR", $"Writing TLOD for VR for address {addrTLOD_VR}");
                MemoryInterface.WriteMemory<float>(addrTLOD_VR, value / 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:SetTLOD VR", $"Exception {ex}: {ex.Message}");
            }
        }
        public void SetOLOD(float value)
        {
            if (allowMemoryWrites)
            {
                SetOLOD_PC(value);
                SetOLOD_VR(value);
            }
        }
        public void SetOLOD_PC(float value)
        {
            try
            {
                MemoryInterface.WriteMemory<float>(addrOLOD, value / 100.0f);
                
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:SetOLOD", $"Exception {ex}: {ex.Message}");
            }
        }
        public void SetOLOD_VR(float value)
        {
            try
            {
                MemoryInterface.WriteMemory<float>(addrOLOD_VR, value / 100.0f);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, "MemoryManager:SetOLOD VR", $"Exception {ex}: {ex.Message}");
            }
        }
        public void SetCloudQ(int value)
        {
            if (allowMemoryWrites)
            {
                try
                {
                    MemoryInterface.WriteMemory<int>(addrCloudQ, value);
                }
                catch (Exception ex)
                {
                    Logger.Log(LogLevel.Error, "MemoryManager:SetCloudQ", $"Exception {ex}: {ex.Message}");
                }
            }
        }
        public void SetCloudQ_VR(int value)
        {
            if (allowMemoryWrites)
            {
                try
                {
                    MemoryInterface.WriteMemory<int>(addrCloudQ_VR, value);
                }
                catch (Exception ex)
                {
                    Logger.Log(LogLevel.Error, "MemoryManager:SetCloudQ VR", $"Exception {ex}: {ex.Message}");
                }
            }
        }
    }
}
